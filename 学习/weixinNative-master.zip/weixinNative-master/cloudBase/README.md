# 微信小程序云开发项目

> 该仓库是关于微信小程序原生开发的所有开源仓库地址，由UP主咸虾米提供，该仓库主要作为引导使用，包含如下模块；
>
> 1.相关项目的仓库地址；
>
> 2.视频学习地址；
>
> 3.体验该项目；
>
> 请给个star吧，代码不断升级项目案例不断开发，请大家持续关注，也可以进入QQ群，有新的项目，会在群里提醒的，Q群：770479352。

![](https://vkceyugu.cdn.bspapp.com/VKCEYUGU-3309c116-4743-47d6-9979-462d2edf878c/0b7fa2fa-06ed-4aa5-bca7-b3f29157a58f.png)

## 🚀微信小程序云开发文档

https://developers.weixin.qq.com/miniprogram/dev/wxcloud/basis/getting-started.html

